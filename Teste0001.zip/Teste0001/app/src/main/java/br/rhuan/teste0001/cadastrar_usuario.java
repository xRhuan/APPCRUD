package br.rhuan.teste0001;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.database.sqlite.SQLiteConstraintException;

public class cadastrar_usuario extends AppCompatActivity {

    private EditText edtNome, edtDataNasc, edtEmail, edtCelular, edtCep, edtNumeroResidencia, edtBairro, edtCidade, edtUf;
    private RadioButton rbSexo;
    private RadioGroup rgSexo;
    private Button btSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        inicializarComponentes();
        DBHelper db = new DBHelper(this);
        btSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = edtNome.getText().toString();
                String dataNasc = edtDataNasc.getText().toString();
                String email = edtEmail.getText().toString();
                String celular = edtCelular.getText().toString();
                String cep = edtCep.getText().toString();
                String numeroResidencia = edtNumeroResidencia.getText().toString();
                String bairro = edtBairro.getText().toString();
                String cidade = edtCidade.getText().toString();
                String uf = edtUf.getText().toString();
                int selectedId = rgSexo.getCheckedRadioButtonId();

                String sexo = "";
                if(selectedId != -1) {
                    rbSexo = findViewById(selectedId);
                    sexo = rbSexo.getText().toString();
                }
                if(nome.equals("")) {
                    Toast.makeText(cadastrar_usuario.this, "Informe um Nome", Toast.LENGTH_SHORT).show();
                }else if (sexo.equals("")){
                    Toast.makeText(cadastrar_usuario.this, "Informe um Sexo", Toast.LENGTH_SHORT).show();
                }else if (dataNasc.equals("")){
                    Toast.makeText(cadastrar_usuario.this, "Informe uma Data", Toast.LENGTH_SHORT).show();
                }else if (email.equals("")){
                    Toast.makeText(cadastrar_usuario.this, "Informe um E-mail", Toast.LENGTH_SHORT).show();
                }else if (celular.equals("")){
                    Toast.makeText(cadastrar_usuario.this, "Informe um Celular", Toast.LENGTH_SHORT).show();
                }else if (cep.equals("")){
                    Toast.makeText(cadastrar_usuario.this, "Informe um Cep", Toast.LENGTH_SHORT).show();
                }else if (numeroResidencia.equals("")){
                    Toast.makeText(cadastrar_usuario.this, "Informe um Numero da Residência", Toast.LENGTH_SHORT).show();
                }else if (bairro.equals("")){
                    Toast.makeText(cadastrar_usuario.this, "Informe uma Bairro", Toast.LENGTH_SHORT).show();
                }else if (cidade.equals("")){
                    Toast.makeText(cadastrar_usuario.this, "Informe uma Cidade", Toast.LENGTH_SHORT).show();
                }else if (uf.equals("")){
                    Toast.makeText(cadastrar_usuario.this, "Informe uma Uf", Toast.LENGTH_SHORT).show();
                }else {
                    try {
                        long res = db.criarUsuario(nome, sexo, dataNasc, email, celular, cep, numeroResidencia, bairro, cidade, uf);
                        if (res > 0) {
                            Toast.makeText(cadastrar_usuario.this, "Cadastro efetuado com Sucesso", Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            Toast.makeText(cadastrar_usuario.this, "Ta Zoando a Firma irmão?", Toast.LENGTH_SHORT).show();
                        }
                    }catch(SQLiteConstraintException error) {
                        Toast.makeText(cadastrar_usuario.this, "O nome informado já está cadastrado.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }

    private void inicializarComponentes() {
        edtNome = (EditText) findViewById(R.id.edtNome);
        edtDataNasc = (EditText)findViewById(R.id.edtDataNasc);
        edtEmail = (EditText)findViewById(R.id.edtEmail);
        edtCelular = (EditText)findViewById(R.id.edtCelular);
        edtCep = (EditText)findViewById(R.id.edtCep);
        edtNumeroResidencia = (EditText)findViewById(R.id.edtNumeroResidencia);
        edtBairro = (EditText)findViewById(R.id.edtBairro);
        edtCidade = (EditText)findViewById(R.id.edtCidade);
        edtUf = (EditText)findViewById(R.id.edtUf);
        rgSexo = (RadioGroup) findViewById(R.id.rgSexo);
        btSalvar = (Button) findViewById(R.id.btSalvar);

    }
}