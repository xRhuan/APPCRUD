package br.rhuan.teste0001;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class excluir_usuario extends AppCompatActivity {

    private Button btExcluir;
    private EditText edtNomeExcluir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_excluir_usuario);
        getSupportActionBar().hide();
        inicializarComponentes();
        DBHelper db = new DBHelper(this);

        btExcluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = edtNomeExcluir.getText().toString();
                String res = db.deletarUsuario(nome);
                try {
                    if (res.equals("OK")) {
                        Toast.makeText(excluir_usuario.this, "Usuário \"" + nome + "\" deletado com sucesso", Toast.LENGTH_LONG).show();
                        finish();
                    }
                } catch (Exception e) {
                    Toast.makeText(excluir_usuario.this, "Opora, tem ninguém com esse nome bicho.", Toast.LENGTH_LONG).show();
                    finish();
                }
            }
        });
    }

    private void inicializarComponentes() {
        btExcluir = findViewById(R.id.btExcluir2);
        edtNomeExcluir = findViewById(R.id.edtNomeExcluir);
    }


}